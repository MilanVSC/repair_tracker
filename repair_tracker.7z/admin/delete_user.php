<?php
include '../includes/config.php';
include '../includes/auth.php';
requireAdmin();

if (!isset($_GET["id"]) || empty(trim($_GET["id"]))) {
    header("location: users.php");
    exit;
}

$user_id = trim($_GET["id"]);

// Preveri, če je uporabnik sam sebe
if ($user_id == $_SESSION["user_id"]) {
    header("location: users.php?error=Ne morete izbrisati lastnega računa.");
    exit;
}

// Preveri, če ima uporabnik povezana popravila
$sql = "SELECT id FROM repairs WHERE reported_by = ? OR assigned_to = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        header("location: users.php?error=Uporabnik ima povezana popravila in ga ni mogoče izbrisati.");
        exit;
    }
    $stmt->close();
}

// Brisanje uporabnika
$sql = "DELETE FROM users WHERE id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        header("location: users.php?success=Uporabnik je bil uspešno izbrisan.");
    } else {
        header("location: users.php?error=Napaka pri brisanju uporabnika.");
    }
    $stmt->close();
}
$conn->close();
?>