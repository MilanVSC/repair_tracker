<?php
include '../includes/config.php';
include '../includes/auth.php';
requireAdmin();

if (!isset($_GET["id"]) || empty(trim($_GET["id"]))) {
    header("location: comments.php");
    exit;
}

$comment_id = trim($_GET["id"]);

// Brisanje komentarja
$sql = "DELETE FROM comments WHERE id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $comment_id);
    if ($stmt->execute()) {
        header("location: comments.php?success=Komentar je bil uspešno izbrisan.");
    } else {
        header("location: comments.php?error=Napaka pri brisanju komentarja.");
    }
    $stmt->close();
}
$conn->close();
?>