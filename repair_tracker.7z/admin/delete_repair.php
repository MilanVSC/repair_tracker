<?php
include '../includes/config.php';
include '../includes/auth.php';
requireAdmin();

if (!isset($_GET["id"]) || empty(trim($_GET["id"]))) {
    header("location: repairs.php");
    exit;
}

$repair_id = trim($_GET["id"]);

// Brisanje komentarjev povezanih s popravilom
$sql = "DELETE FROM comments WHERE repair_id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $repair_id);
    $stmt->execute();
    $stmt->close();
}

// Brisanje zgodovine statusov
$sql = "DELETE FROM status_history WHERE repair_id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $repair_id);
    $stmt->execute();
    $stmt->close();
}

// Brisanje popravila
$sql = "DELETE FROM repairs WHERE id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $repair_id);
    if ($stmt->execute()) {
        header("location: repairs.php?success=Popravilo je bilo uspešno izbrisano.");
    } else {
        header("location: repairs.php?error=Napaka pri brisanju popravila.");
    }
    $stmt->close();
}
$conn->close();
?>