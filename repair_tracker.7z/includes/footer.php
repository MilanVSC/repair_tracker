        </main>
    <footer>
        <p>Sistem za sledenje popravilom &copy; <?php echo date('Y'); ?></p>
    </footer>
</body>
</html>